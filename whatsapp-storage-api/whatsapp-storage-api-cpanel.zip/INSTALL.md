# cPanel Installation Instructions

## Step 1: Upload Files
1. Compress the whatsapp-storage-api-deploy folder to a ZIP file
2. Upload the ZIP file to your cPanel File Manager
3. Extract the files to your desired directory (e.g., /public_html/api/)

## Step 2: Setup Node.js Application (cPanel)
1. Go to cPanel > Node.js Apps
2. Click "Create Application"
3. Select Node.js version (14+ recommended)
4. Set Application Root: /public_html/api (or your chosen directory)
5. Set Application URL: api.yourdomain.com (or subdirectory)
6. Set Startup File: startup.js
7. Click "Create"

## Step 3: Install Dependencies
1. In Node.js Apps, click "Run NPM Install" for your application
2. Wait for installation to complete

## Step 4: Environment Configuration
1. In your application directory, copy .env.example to .env
2. Edit .env file with your settings:
   ```
   API_KEY=your-unique-secret-key
   PORT=3001
   MAX_FILE_SIZE=10485760
   ```

## Step 5: Start Application
1. In Node.js Apps, click "Start" for your application
2. Your API will be available at your configured URL

## Step 6: Test API
1. Visit: https://yourdomain.com/api/health
2. Should return: {"status": "ok", "timestamp": "..."}

## Troubleshooting
- Check cPanel Error Logs if the application fails to start
- Ensure all file permissions are correct (644 for files, 755 for directories)
- Verify Node.js version compatibility
- Check that the startup file is correctly configured
