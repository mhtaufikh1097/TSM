// Startup file for cPanel Node.js application
const app = require('./server.js');

const PORT = process.env.PORT || 3001;

if (app && typeof app.listen === 'function') {
    app.listen(PORT, () => {
        console.log(`WhatsApp Storage API running on port ${PORT}`);
    });
} else {
    // If server.js exports the app, start it
    console.log('Server started from startup.js');
}
